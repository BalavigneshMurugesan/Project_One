
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms'; 


export interface BankElement {
  Recruitment: string;
  course: string;
  Age: string;
  Eq: string;
Ep: string;
Salary:string;

}


const Bank_Data: BankElement[] = [
  {course: 'Bank', Recruitment: 'IBPS Specialist Officer', Age: '21 - 30 Yrs', Eq: 'Any Professional Degree - Computer Awareness', Ep:'Prelims, Mains, Interview', Salary:'₹ 42,000'},
  {course: 'Bank', Recruitment: 'SBI Junior Associates', Age: '20 - 28 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains.', Salary:'₹ 31,000'},
  {course: 'Bank', Recruitment: 'SBI Probationary Officers', Age: '20 - 28 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains, Interview', Salary:'₹ 54,000'},
  {course: 'Bank', Recruitment: 'IBPS RRB Clerk', Age: '20 - 28 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains.', Salary:'₹ 22,000'},
  {course: 'Bank', Recruitment: 'IBPS RRB Probationary Officers', Age: '20 - 30 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains, Interview', Salary:'₹ 45,000'},
  {course: 'Bank', Recruitment: 'IBPS Clerk', Age: '20 - 30 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains.', Salary:'₹ 22,000'},
  {course: 'Bank', Recruitment: 'IBPS Probationary Officer', Age: '20 - 30 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains, Interview', Salary:'₹ 48,000'},
  {course: 'Bank', Recruitment: 'RBI Grade B', Age: '20 - 30 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains, Interview', Salary:'₹ 68,000'},
  {course: 'Bank', Recruitment: 'RBI Assistants', Age: '20 - 30 Yrs', Eq: 'Any Degree', Ep:'Prelims, Mains.', Salary:'₹ 32,000'},
];


export interface SscElement {
  Ssc: string;
  Designation: string;
  Department: string;
  Education: string;
Age: string;
Tier:string;

}

const Ssc_Data: SscElement[] = [
  {Ssc: 'SSC CGL', Designation: 'Assistant Audit Officer', Age: '21 - 30 Yrs', Education: 'Any Degree', Department:'Indian Audit & Accounts Department under C&AG', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Assistant Accounts Officer', Age: '20 - 28 Yrs', Education: 'Any Degree', Department:'Indian Audit & Accounts Department under C&AG', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Assistant Section Officer', Age: '20 - 30 Yrs', Education: 'Any Degree', Department:'Prelims, Mains, Interview', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Inspector of Income Tax', Age: '20 - 28 Yrs', Education: 'Any Degree', Department:'CBDT', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Inspector (Central Excise)', Age: '20 - 30 Yrs', Education: 'Any Degree', Department:'CBDT', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Assistant Enforcement Officer', Age: '20 - 28 Yrs', Education: 'Any Degree', Department:'CBIC', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Sub Inspector', Age: '20 - 30 Yrs', Education: 'Any Degree', Department:'CBIC', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Inspector', Age: '20 - 30 Yrs', Education: 'Any Degree', Department:'Central Bureau of Investigation', Tier:'1,2,3,4'},
  {Ssc: 'SSC CGL', Designation: 'Sub Inspector', Age: '20 - 28 Yrs', Education: 'Any Degree', Department:'Central Bureau of Investigation', Tier:'1,2,3,4'},
];



export interface TnpscElement {
  Group: string;
  Age: string;
  Exam: string;
  Edu: string;
  AgeRelaxations: string;
  Syllabus:string;

}

const Tnpsc_Data: TnpscElement[] = [
  {Group:'Group I',Age: '21 - 32  O.C,F.C', AgeRelaxations: '21-37 years-Rest of the communities', Edu: 'Any Degree', Exam:'Prelims, Mains & Interview', Syllabus:'6 -10 Samacheer Books'},
  {Group:'Group II & IIA',Age: '21 - 32  O.C,F.C', AgeRelaxations: '21-37 years-Rest of the communities', Edu: 'Any Degree', Exam:'Prelims, Mains & Interview', Syllabus:'6 -10 Samacheer Books'},
  {Group:'Group IV',Age: 'VAO- 21-30, Junior Assistance-18 - 30', AgeRelaxations: 'Rest of communitiesVAO min 21-35 for 10th or 12th Junior Assistant(J.A)- min 18-35 for 12th, Degree holders maximum is 45 years for VAO,J.A', 
  Edu: '10th / 12th', Exam: 'Prelims only ( 300 MCQ)', Syllabus:'6 -10 Samacheer Books'},
  ];



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FirstApp';

  displayedColumnsBank: string[] = ['course', 'Recruitment', 'Age', 'Eq', 'Ep', 'Salary'];
  bankSource = Bank_Data;


  displayedColumnsSsc: string[] = ['Ssc', 'Designation', 'Department', 'Education', 'Age', 'Tier'];
  sscSource = Ssc_Data;

  displayedColumnsTnpsc: string[] = ['Group', 'Age', 'Exam', 'Edu', 'AgeRelaxation', 'Syllabus'];
tnpscSource = Tnpsc_Data;



bankDetails = new FormGroup({

name:new FormControl(''),
age:new FormControl(''),
Education:new FormControl(''),
caste:new FormControl(''),
Examination:new FormControl(''),

})
  

  


public getIn=''


collection():any{
  console.warn(this.bankDetails.value)
  console.info("success")
   
  
    if (this.bankDetails.value.Examination=='Bank') {    
    
    
         if (this.bankDetails.value.age>='20'&& this.bankDetails.value.age <='30') {
       
               if (this.bankDetails.value.age =='20'){
      
                this.bankSource=  Bank_Data.filter(item => item.Age!=='21 - 30 Yrs' )
                this.getIn='getbank'
  
                }          
  
               else if (this.bankDetails.value.age =='29' || this.bankDetails.value.age =='30'){
                this.bankSource=  Bank_Data.filter(item => item.Age!=='20 - 28 Yrs' )
                 this.getIn='getbank'
                    }
                  else if (this.bankDetails.value.age =='21' || this.bankDetails.value.age =='22' || this.bankDetails.value.age =='23' || this.bankDetails.value.age =='24'
                  || this.bankDetails.value.age =='25' || this.bankDetails.value.age =='26' || this.bankDetails.value.age =='27' || this.bankDetails.value.age =='28'){ 
                  
                    this.bankSource=  Bank_Data
                      this.getIn='getbank'
                    }
         }
      
          else this.getIn='null'
    }

    
    
    else if (this.bankDetails.value.Examination=='SSC'){
        
             this.getIn='getssc'
        }

        else
        {

                   if ((this.bankDetails.value.age>'20'&& this.bankDetails.value.age <'33') 
                   && (this.bankDetails.value.caste =='OC' || this.bankDetails.value.caste =='FC')) {

                  this.tnpscSource = Tnpsc_Data.filter(item => item.Age!=='VAO- 21-30, Junior Assistance-18 - 30')
                  this.getIn='gettnpsc'


                   } 
                   else if ((this.bankDetails.value.age>'20'&& this.bankDetails.value.age <'31') ||
                   (this.bankDetails.value.age>'17'&& this.bankDetails.value.age <'31'))
                   {
                    this.tnpscSource = Tnpsc_Data.filter(item => item.Age!=='21 - 32  O.C,F.C')
                    this.getIn='gettnpsc'
  
                     }          else this.getIn='null'




        }

  }
    






}
